# Lookup Mobile Hub: everything in one package

| Zip | What's in it |
|---|---|
| `1-admin-server.zip` | Admin panel, server/API/database, AI support backend, deploy files, production docs |
| `2-android-app.zip` | The Android project (API 36) and the `play-store/` kit: guide, listing text, icon, graphics, screenshots |
| `3-website.zip` | Landing page with download page, AI support chat, privacy policy, delete-account page, and the full web app at `/app/` |

The website and the Android app both talk to the server in zip 1: same accounts, wallets and support, all controlled from the admin panel.

Order: 1) deploy the server and add your `ANTHROPIC_API_KEY`; 2) put the server address in the app's `config.js`; 3) follow `play-store/PLAY-STORE-GUIDE.md` to build the signed files; 4) put the APK in the website's `downloads/` folder and upload the `.aab` to Google Play.

Honest limits: card funding, SMS codes and vendor delivery need real providers (do not submit to Google Play before that); the single-file database is for launch, not millions of users; the Android build could not be compiled where it was written, so the first GitHub run is its first real test; the privacy policy is a template to complete and have reviewed.
